import React from 'react';

const Navbar = () => {
    return <nav><h2>Softchat Navbar</h2></nav>;
};

export default Navbar;